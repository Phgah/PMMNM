<?php
/**
 * Plugin Name: Quick Chat Button
 * Description: Hiển thị nút chat với Messenger và Zalo trên website.
 * Version: 1.0
 * Author: Your Name
 * License: GPL2
 */

// Kích hoạt plugin
function qcb_activate() {
    // Tạo các tùy chọn mặc định cho plugin
    add_option('qcb_messenger_enabled', '1');
    add_option('qcb_zalo_enabled', '1');
    add_option('qcb_messenger_url', 'https://m.me/yourbusiness');
    add_option('qcb_zalo_phone', '+84901234567');
    add_option('qcb_button_text', 'Chat ngay');
    add_option('qcb_messenger_color', '#0084FF');
    add_option('qcb_zalo_color', '#25D366');
}
register_activation_hook(__FILE__, 'qcb_activate');

// Hủy kích hoạt plugin
function qcb_deactivate() {
    delete_option('qcb_messenger_enabled');
    delete_option('qcb_zalo_enabled');
    delete_option('qcb_messenger_url');
    delete_option('qcb_zalo_phone');
    delete_option('qcb_button_text');
    delete_option('qcb_messenger_color');
    delete_option('qcb_zalo_color');
}
register_deactivation_hook(__FILE__, 'qcb_deactivate');

// Thêm menu cài đặt trong WordPress Admin
function qcb_add_admin_menu() {
    add_menu_page('Quick Chat Button', 'Quick Chat Button', 'manage_options', 'qcb-settings', 'qcb_settings_page');
}
add_action('admin_menu', 'qcb_add_admin_menu');

// Trang cài đặt của plugin
function qcb_settings_page() {
    ?>
    <div class="wrap">
        <h1>Quick Chat Button Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('qcb_options_group');
            do_settings_sections('qcb-settings');
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Kích hoạt Messenger</th>
                    <td><input type="checkbox" name="qcb_messenger_enabled" value="1" <?php checked(1, get_option('qcb_messenger_enabled'), true); ?> /></td>
                </tr>
                <tr>
                    <th scope="row">Messenger URL</th>
                    <td><input type="text" name="qcb_messenger_url" value="<?php echo esc_attr(get_option('qcb_messenger_url')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Kích hoạt Zalo</th>
                    <td><input type="checkbox" name="qcb_zalo_enabled" value="1" <?php checked(1, get_option('qcb_zalo_enabled'), true); ?> /></td>
                </tr>
                <tr>
                    <th scope="row">Số điện thoại Zalo</th>
                    <td><input type="text" name="qcb_zalo_phone" value="<?php echo esc_attr(get_option('qcb_zalo_phone')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Nội dung nút chat</th>
                    <td><input type="text" name="qcb_button_text" value="<?php echo esc_attr(get_option('qcb_button_text')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Màu sắc Messenger</th>
                    <td><input type="color" name="qcb_messenger_color" value="<?php echo esc_attr(get_option('qcb_messenger_color')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row">Màu sắc Zalo</th>
                    <td><input type="color" name="qcb_zalo_color" value="<?php echo esc_attr(get_option('qcb_zalo_color')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Đăng ký các tùy chọn
function qcb_register_settings() {
    register_setting('qcb_options_group', 'qcb_messenger_enabled');
    register_setting('qcb_options_group', 'qcb_zalo_enabled');
    register_setting('qcb_options_group', 'qcb_messenger_url');
    register_setting('qcb_options_group', 'qcb_zalo_phone');
    register_setting('qcb_options_group', 'qcb_button_text');
    register_setting('qcb_options_group', 'qcb_messenger_color');
    register_setting('qcb_options_group', 'qcb_zalo_color');
}
add_action('admin_init', 'qcb_register_settings');
// Liên kết CSS cho plugin
function qcb_enqueue_styles() {
    wp_enqueue_style('qcb-style', plugin_dir_url(__FILE__) . 'css/style.css');
}
add_action('wp_enqueue_scripts', 'qcb_enqueue_styles');
// Liên kết FontAwesome
// Liên kết FontAwesome
function qcb_enqueue_fontawesome() {
    wp_enqueue_script('fontawesome', 'https://kit.fontawesome.com/a076d05399.js', [], null, true);
}
add_action('wp_enqueue_scripts', 'qcb_enqueue_fontawesome');


// Hiển thị nút chat trên frontend
function qcb_display_chat_button() {
    $messenger_enabled = get_option('qcb_messenger_enabled');
    $zalo_enabled = get_option('qcb_zalo_enabled');
    $messenger_url = get_option('qcb_messenger_url');
    $zalo_phone = get_option('qcb_zalo_phone');
    $button_text = get_option('qcb_button_text');
    $messenger_color = get_option('qcb_messenger_color');
    $zalo_color = get_option('qcb_zalo_color');

    ?>
    <div id="qcb-chat-buttons" style="position: fixed; bottom: 10px; right: 10px;">
        <?php if ($messenger_enabled): ?>
            <a href="<?php echo esc_url($messenger_url); ?>" target="_blank" style="background-color: <?php echo esc_attr($messenger_color); ?>;">
                <i class="fab fa-facebook-messenger"></i> Chat ngay với Messenger
            </a>
        <?php endif; ?>

        <?php if ($zalo_enabled): ?>
            <a href="https://api.zalo.me/officialchat?phone=<?php echo esc_attr($zalo_phone); ?>" target="_blank" style="background-color: <?php echo esc_attr($zalo_color); ?>;">
                <i class="fab fa-whatsapp"></i> Chat ngay với Zalo
            </a>
        <?php endif; ?>
    </div>
    <?php
}

add_action('wp_footer', 'qcb_display_chat_button');
